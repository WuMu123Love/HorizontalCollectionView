//
//  MADataHelper.h
//  MAHorizontalCollectionView
//
//  Created by mengai on 2017/7/10.
//  Copyright © 2017年 mengai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MADataHelper : NSObject

+ (NSArray *)loadTestData;

@end
