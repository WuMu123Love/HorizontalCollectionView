//
//  MAPageControl.h
//  TairanTV
//
//  Created by mengai on 2017/5/25.
//  Copyright © 2017年 mengai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MAPageControl : UIPageControl

@property (nonatomic, strong) UIImage *normalImage;
@property (nonatomic, strong) UIImage *selectedImage;

@end
