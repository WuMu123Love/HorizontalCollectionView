//
//  MAItemCell.h
//  TairanTV
//
//  Created by mengai on 2017/5/13.
//  Copyright © 2017年 mengai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MAApiItemListModel.h"

@interface MAItemCell : UICollectionViewCell

@property (nonatomic, strong) MAApiItemItemModel *itemModel;

@end
