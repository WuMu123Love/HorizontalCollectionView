//
//  MAApiItemListModel.m
//  TairanTV
//
//  Created by mengai on 2017/5/15.
//  Copyright © 2017年 mengai. All rights reserved.
//

#import "MAApiItemListModel.h"

@implementation MAApiItemItemModel

@end

@implementation MAApiItemListModel

@end

@implementation MAApiItemSendSuccessModel

@end
