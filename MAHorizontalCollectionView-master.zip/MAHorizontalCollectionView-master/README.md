横向可分页UICollectionView
==
支持横竖屏不同布局. 

竖屏：

* 支持点击tab切换类别；

* 支持左右滑动；

* 支持显示or隐藏页码.

横屏：

* 支持点击tab切换类别；

* 支持左右滑动；

* 支持当前上下滑动.


演示效果gif：

![](https://github.com/ma762614600/ResourceRepository/blob/master/image/gif/collectionView.gif)


文章地址： http://www.jianshu.com/p/dbf9e1e3fb34
